#include <iostream>
#include <cstring>
#include <cstdlib>
#include <sstream>
#include <vector>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
using namespace std;

int main() {
    int sockfd;
    struct sockaddr_in server_address;
    struct hostent *server;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    // server = gethostbyname("inp.zoolab.org");

    const char* host = "172.21.0.4";
    const int port = 10001;

    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;

    // memcpy(&server_address.sin_addr.s_addr, server->h_addr, server->h_length);

    if (inet_pton(AF_INET, host, &(server_address.sin_addr)) <= 0) {
        cerr << "Invalid address or address not supported" << endl;
        return 1;
    }
    
    server_address.sin_port = htons(port);

    connect(sockfd, (struct sockaddr *)&server_address, sizeof(server_address));

    const char *request = "GET /otp?name=110550111 HTTP/1.1\r\nHost: 172.21.0.4:10001\r\nConnection: Keep-Alive\r\n\r\n";

    int bytes_sent = send(sockfd, request, strlen(request), 0);
    if (bytes_sent < 0) {
        perror("Error sending request");
        return 1;
    }

    string last_line;

    char buffer[8000];
    int bytes_received;
    while ((bytes_received = recv(sockfd, buffer, sizeof(buffer) - 1, 0) )> 0) {
        buffer[bytes_received] = '\0';
        cout << buffer << "\n";
        last_line = buffer;
    }

    istringstream iss(last_line);
    vector<string> words;

    string word;
    while (getline(iss, word, '\n')) {
        words.push_back(word);
    }

    last_line = words[words.size()-1];

    cout << "last: " << last_line << "\n";

    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    connect(sockfd, (struct sockaddr *)&server_address, sizeof(server_address));

    const char *post_header = "POST /upload HTTP/1.1\r\nHost: 172.21.0.4:10001\r\nContent-Length: ";
    
    int file_size = last_line.length();

    file_size += 190;

    char content_length[20];
    snprintf(content_length, sizeof(content_length), "%d", file_size);
    string post_request = post_header + string(content_length);

    post_request += "\r\nContent-Type: multipart/form-data; boundary=------------------------09ee2529a47a6028\r\n\r\n--------------------------09ee2529a47a6028\r\n";
    post_request += "Content-Disposition: form-data; name=\"file\"; filename=\"response.txt\"\r\n";
    post_request += "Content-Type: text/plain\r\n\r\n";

    bytes_sent = send(sockfd, post_request.c_str(), post_request.length(), 0);
    if (bytes_sent < 0) {
        perror("Error sending request");
        return 1;
    }

    send(sockfd, last_line.c_str(), last_line.length(), 0);

    post_request = "\r\n--------------------------09ee2529a47a6028--\r\n";
    send(sockfd, post_request.c_str(), post_request.length(), 0);

    char response[4096];
    bytes_received = 0;
    while ((bytes_received = recv(sockfd, response, sizeof(response) - 1, 0)) > 0) {
        response[bytes_received] = '\0';
        cout << response;
    }

    return 0;
}
