#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <chrono>
#include <sys/time.h>

using namespace std;

#define BUFFER_SIZE 1024

int main() {
    int serverSocket, clientSocket;
    struct sockaddr_in serverAddr, clientAddr;
    socklen_t clientAddrLen = sizeof(clientAddr);
    char buffer[BUFFER_SIZE];

    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    serverAddr.sin_port = htons(8888);

    if (bind(serverSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Binding failed");
        exit(EXIT_FAILURE);
    }

    if (listen(serverSocket, 5) < 0) {
        perror("Listening failed");
        exit(EXIT_FAILURE);
    }

    printf("Server waiting for connections...\n");

    while (1) {
        clientSocket = accept(serverSocket, (struct sockaddr *)&clientAddr, &clientAddrLen);
        if (clientSocket < 0) {
            perror("Acceptance failed");
            exit(EXIT_FAILURE);
        }

        pid_t pid = fork();
        if (pid == 0) {
			
			recv(clientSocket, buffer, BUFFER_SIZE, 0);
			send(clientSocket, buffer, BUFFER_SIZE, 0);

            // Measure throughput
		    for(int i=0;i<50;i++){
		    	char message[1024*1024];
		    	memset(message, 'A', sizeof(message));
		    	int num;
		    	if ((num=send(clientSocket, message, sizeof(message), 0)) == -1) {
		    		perror("Error: Send failed.");
		    		break;
		    	}
		    }

            close(serverSocket); // Close server socket in child process
            exit(EXIT_SUCCESS);
        } else {
            close(clientSocket); // Close client socket in parent process
        }
    }
    close(serverSocket);
    return 0;
}