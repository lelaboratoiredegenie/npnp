#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <chrono>
#include <sys/time.h>

using namespace std;

#define BUFFER_SIZE 1024

int main() {
    int clientSocket;
    struct sockaddr_in serverAddr;
    char buffer[BUFFER_SIZE];

    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(8888);
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1"); // Replace with your server IP

    if (connect(clientSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Connection failed");
        exit(EXIT_FAILURE);
    }

    (buffer, 'a', BUFFER_SIZE); 

    auto timeStart = chrono::high_resolution_clock::now();
    send(clientSocket, buffer, BUFFER_SIZE, 0);
	recv(clientSocket, buffer, BUFFER_SIZE, 0);
	auto timeEnd = chrono::high_resolution_clock::now();
    long long latency = chrono::duration_cast<chrono::milliseconds>(timeEnd - timeStart).count();
    
    long long int get_bytes=0;
    struct timeval start_recv;
    struct timeval end_recv;
    double recv_time=0;
    int all_get_bytes=0;
    while(all_get_bytes<50*1024*1024){
        char buffer[1024*1024];
        gettimeofday(&start_recv, NULL);
        int bytesRead = recv(clientSocket, buffer, sizeof(buffer), 0);
        gettimeofday(&end_recv, NULL);
        double cur_recv_time=end_recv.tv_sec-start_recv.tv_sec+(end_recv.tv_usec-start_recv.tv_usec)*0.000001;
        if (bytesRead == -1) {
            perror("Receive failed.");
        } else {
            if(cur_recv_time<0.005) {
                recv_time += cur_recv_time;
                get_bytes += (bytesRead+66);
            }
            all_get_bytes += bytesRead;
        }
    }

    double ans=get_bytes/recv_time;
    
    int bandwidth = int(ans / 1000000.0 * 8);

    printf("RESULTS: delay = %lld ms, bandwidth = %d Mbps\n", latency/2, bandwidth);

    close(clientSocket);

    return 0;
}

