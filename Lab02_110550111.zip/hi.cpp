#include <iostream>
#include <fcntl.h>
#include <unistd.h>
#include <cstring>
#include <vector>
#include <iomanip>
#include <cstdlib>
using namespace std;

typedef struct {
    uint64_t magic;     /* 'BINFLAG\x00' */
    uint32_t datasize;  /* in big-endian */
    uint16_t n_blocks;  /* in big-endian */
    uint16_t zeros;
} __attribute((packed)) binflag_header_t;

typedef struct {
    uint32_t offset;        /* in big-endian */
    uint16_t cksum;         /* XOR'ed results of each 2-byte unit in payload */
    uint16_t length;        /* ranges from 1KB - 3KB, in big-endian */
    // int payload_num;
} __attribute((packed)) block_t;

typedef struct {
   uint16_t length;        /* length of the offset array, in big-endian */
//    uint32_t offset[0];     /* offset of the flags, in big-endian */
} __attribute((packed)) flag_t;


string to_hex(uint16_t ic)
{
    string h;
    stringstream stream;
    stream << hex << ic;
    h = stream.str();

    if(h.length() == 3) h = "0" + h;
    else if(h.length() == 2) h = "00" + h;
    else if(h.length() == 1) h = "000" + h;

    return h;
}

int main()
{
    int fd;
    uint16_t n_blocks;
    uint32_t datasize;
    vector<block_t> blocks;
    vector<vector<uint16_t>> payload;
    vector<uint16_t> ans;
    vector<string> dict;
    vector<uint32_t> fls;

    const char * cmd_d = "curl https://inp.zoolab.org/binflag/challenge?id=110550111 --output challenge.bin";
    system(cmd_d);

    cout << "Downloaded.\n";

    char buf[128];
    memset(buf, '\0', sizeof(buf));

    fd = open("challenge.bin", O_RDONLY);
    read(fd, buf, 8);
    read(fd, &datasize, 4);
    read(fd, &n_blocks, 2);
    read(fd, buf+8, 2);

    datasize = __builtin_bswap32(datasize);
    n_blocks = __builtin_bswap16(n_blocks);

    blocks.resize(n_blocks);
    payload.resize(n_blocks);
    ans.resize(n_blocks);
    dict.resize(datasize);


    for(int i=0; i<n_blocks; i++)
    {
        read(fd, &blocks[i].offset, 4);
        blocks[i].offset = __builtin_bswap32(blocks[i].offset);

        read(fd, &blocks[i].cksum, 2);

        read(fd, &blocks[i].length, 2);
        blocks[i].length = __builtin_bswap16(blocks[i].length);
        payload[i].resize(blocks[i].length);

        uint16_t ans_t = 0;

        for(int j=0; j<blocks[i].length/2; j++)
        {
            read(fd, &payload[i][j], 2);
            ans_t ^= payload[i][j];
        }
        
        if(ans_t == blocks[i].cksum)
        {
            for(int j = 0; j<blocks[i].length/2; j++)
            {
                string tmp = to_hex(payload[i][j]);
                string part1 = tmp.substr(0,2);
                string part2 = tmp.substr(2,2);
                dict[blocks[i].offset + j*2] = part2;
                dict[blocks[i].offset + j*2 + 1] = part1;
            }
        }
    }

    cout << "Dict ok.\n";

    flag_t flag;
    read(fd, &flag.length, 2);
    flag.length = __builtin_bswap16(flag.length);
    
    string anss;
    fls.resize(flag.length);
    for(int i = 0; i < flag.length ; i++)
    {
        read(fd, &fls[i], 4);
        fls[i] = __builtin_bswap32(fls[i]);
        anss += dict[fls[i]];
        anss += dict[fls[i]+1];
    }

    close(fd);
    cout << anss << "\n";
    
    string cmd = "curl https://inp.zoolab.org/binflag/verify?v=" + anss;
    const char * cmd_c = cmd.c_str();
    system(cmd_c);
}