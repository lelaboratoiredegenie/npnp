import subprocess
import threading
import socket
import time
import sys
from scapy.all import *

command = ["sudo", "tcpdump", "-ni", "any", "-Xxnv", "udp and port 10495", "-w", "/home/lecadeau/lab1/lab1.pcap"]

def load_seq(packet, start, end, header_dict):
    raw_data = packet[Raw].load
    text_data = raw_data.decode()
    ip_header = packet[IP]

    if "SEQ" in text_data:
        header_dict[int(text_data[4:9])] = ip_header.len - 28

    if "BEGIN FLAG" in text_data:
        start = int(text_data[4:9])
    if "END FLAG" in text_data:
        end = int(text_data[4:9])

    return start, end, header_dict

def decodeee():

    time.sleep(1)

    packets = rdpcap("lab1.pcap")

    start = 0
    end = 0

    header_dict = {}

    for packet in packets:
        start, end, header_dict = load_seq(packet, start, end, header_dict)

    ans = ''

    for i in range(end-start-1):
        cur = i+start+1
        if cur not in header_dict:
            print("lost package no. " + str(cur))
            return "some packages are lost."
        else:
            ans += chr(header_dict[cur])
    return ans


def listen():
    try:
        print("start listening")
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error: {e}")
        print(f"Error Output: {e.stderr}")

def everything_else():
    
    id = input("your id: ")
    server_address = ("127.0.0.1", 10495)
    # server_address = ("inp.zoolab.org", 10495)

    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    message = "hello "+id
    udp_socket.sendto(message.encode(), server_address)
    data, server = udp_socket.recvfrom(1024)
    challenge_id = data.decode()[3:]

    print("reply id:", data.decode())
    
    message = "chals_"+challenge_id 
    udp_socket.sendto(message.encode(), server_address)
    i = 0

    while True:
        data, server = udp_socket.recvfrom(100000)
        i += 1
        if i > 150:
            break

    time.sleep(5)

    ans = decodeee()
    
    print(ans)

    if "lost" in ans:
        sys.exit()

    time.sleep(3)

    message = "verfy" + ans
    udp_socket.sendto(message.encode(), server_address)

    while True:
        data, server = udp_socket.recvfrom(1024)
        print(data.decode())
    
    
listen_thread = threading.Thread(target=listen)
connect_thread = threading.Thread(target=everything_else)

listen_thread.start()

connect_thread.start()