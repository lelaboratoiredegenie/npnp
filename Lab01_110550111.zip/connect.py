import socket
import time

id = input("your id: ")

# server_address = ("inp.zoolab.org", 10495)
server_address = ("127.0.0.1", 10495)

udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

try:
    message = "hello "+id
    udp_socket.sendto(message.encode(), server_address)
    data, server = udp_socket.recvfrom(1024)
    challenge_id = data.decode()[3:]

    print("reply id:", data.decode())

    message = "chals_"+challenge_id 
    udp_socket.sendto(message.encode(), server_address)
    # data, server = udp_socket.recvfrom(100000)

    i = 0

    while True:
        data, server = udp_socket.recvfrom(100000)
        i += 1
        if i > 150:
            break
            



    # time.sleep(5)


    ans = input("your ans: ")

    message = "verfy " + ans
    udp_socket.sendto(message.encode(), server_address)
    i = 0
    while True:
        data, server = udp_socket.recvfrom(100000)
        i += 1
        if i > 150:
            break
        else:
            print(data.decode())
    


finally:
    udp_socket.close()
