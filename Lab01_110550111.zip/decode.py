from scapy.all import *

    
def load_seq(packet, start, end):
    raw_data = packet[Raw].load
    text_data = raw_data.decode()
    ip_header = packet[IP]

    if "SEQ" in text_data:
        header_dict[int(text_data[4:9])] = ip_header.len - 28

    if "BEGIN FLAG" in text_data:
        start = int(text_data[4:9])
    if "END FLAG" in text_data:
        end = int(text_data[4:9])

    return start, end
    
        

# Load the packet capture file or capture packets in real-time
packets = rdpcap("lab1.pcap")  # Change to your actual packet capture file


start = 0
end = 0

header_dict = {}

# Process each packet and calculate x-header-length
for packet in packets:
    start, end= load_seq(packet, start, end)


ans = ''

for i in range(end-start-1):
    cur = i+start+1
    if cur not in header_dict:
        print(cur)
        break
    else:
        ans += chr(header_dict[cur])

print(ans)

print(start, end)
