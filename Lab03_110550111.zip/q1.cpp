#include <bits/stdc++.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <cstring>
#include <vector>
using namespace std;

char maze[7][11] = {'0'};
string ans = "";

int main()
{
    char buf[100000];
    int socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    
    struct sockaddr_in info;
    bzero(&info, sizeof(info));
    
    info.sin_family = AF_INET;
    const char* host = "inp.zoolab.org";

    struct hostent *server = gethostbyname(host);
    if (server == NULL) {
        perror("Error resolving hostname");
        return 1;
    }

    bcopy((char *)server->h_addr, (char *)&info.sin_addr.s_addr, server->h_length);
    info.sin_port = htons(10301);

    int conn_erro = connect(socket_fd, (struct sockaddr*)&info, sizeof(info));

    if(conn_erro == -1) cout << "Connection Error\n";

    int w=11,h=7;
    

    while (1)
    {
        bzero(&buf, sizeof(buf));
        long long nbytes = recv(socket_fd, buf, sizeof(buf), 0);

    
        char* found0 = strstr(buf, "##");
        if (found0 != nullptr)
        {
            int it = found0 - buf;
            for(int i=0; i<h; i++)
            {
                for(int j=0; j<w; j++)
                {
                    maze[i][j] = buf[it];
                    it += 1;
                }
                it += 1;
            }
        }
        char* found = strstr(buf, "Enter your move");

        for(long long i = 0; i < nbytes ; i++) cout << buf[i]; cout << "\n";
        if (found != nullptr) break;
    }

    int startX, startY, endX, endY;
    for (int i = 0; i < h; i++) {
        for (int j = 0; j < w; j++) {
            if (maze[i][j] == '*') {
                startX = i;
                startY = j;
                break;
            }
            else if(maze[i][j] == 'E'){
                endX = i;
                endY = j;
                break;
            }
        }
    }

    if(endX > startX)
    {
        for(int i=0; i<endX-startX; i++)
        {
            ans += 's';
        }
    }
    else if(endX < startX)
    {
        for(int i=0; i<startX-endX; i++)
        {
            ans += 'w';
        }
    }

    if(endY > startY)
    {
        for(int i=0; i<endY-startY; i++)
        {
            ans += 'd';
        }
    }
    else if(endY < startY)
    {
        for(int i=0; i<startY-endY; i++)
        {
            ans += 'a';
        }
    }

    ans += '\n';

    cout << ans << "\n";

    send(socket_fd, ans.c_str(), sizeof(ans.c_str()), 0);
    bzero(&buf, sizeof(buf));
    long long nbytes = recv(socket_fd, buf, sizeof(buf), 0); // listen to the 
    for(long long i = 0; i < nbytes ; i++) cout << buf[i]; cout << "\n";

    bzero(&buf, sizeof(buf));
    nbytes = recv(socket_fd, buf, sizeof(buf), 0); // listen to the 
    for(long long i = 0; i < nbytes ; i++) cout << buf[i]; cout << "\n";

    bzero(&buf, sizeof(buf));
    nbytes = recv(socket_fd, buf, sizeof(buf), 0); // listen to the 
    for(long long i = 0; i < nbytes ; i++) cout << buf[i]; cout << "\n";


        
}