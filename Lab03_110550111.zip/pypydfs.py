import socket

server_addr = ("inp.zoolab.org", 10302)

def find_path(maze, start):
    
    # initialize the queue
    stack = []
    stack.append((start, ""))
    visited = []
    visited.append(start)
    path = ''
    while stack:
        cur, cur_path = stack.pop(-1)
        y = cur[0]
        x = cur[1]
        if maze[y][x] == 'E':
            path = cur_path
            break
        if maze[y-1][x] in ['.', 'E'] and (y-1, x) not in visited:
            stack.append(((y-1, x), cur_path+'W'))
            visited.append((y-1, x))
        if maze[y+1][x] in ['.', 'E'] and (y+1, x) not in visited:
            stack.append(((y+1, x), cur_path+'S'))
            visited.append((y+1, x))
        if maze[y][x-1] in ['.', 'E'] and (y, x-1) not in visited:
            stack.append(((y, x-1) , cur_path+'A'))
            visited.append((y, x-1))
        if maze[y][x+1] in ['.', 'E'] and (y, x+1) not in visited:
            stack.append(((y, x+1), cur_path+'D'))
            visited.append((y, x+1))
    return path

def send_path(s, path):
    s.send(path.encode())
    tmp = s.recv(1024)    
    flag = s.recv(1024).decode()[1:]
    return flag
        
    
width = 79
height = 21
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(server_addr)
    
while True:
    buf = s.recv(1024).decode()
      
    width = 79
    height = 21
    found = buf.find('\n#')
    if (found == -1):
        continue

    maze = buf[found+1:]
    while True:
        remained_mazes = s.recv(1024).decode()
        maze += remained_mazes
        if 'Enter your move(s)>' in remained_mazes:
            break
        
    print(maze)
    maze = maze.split('\n')
    maze = maze[:-3]
    
    for (i, c) in enumerate(maze):
        for (j, d) in enumerate(c):
            if d == '*':
                start = (i, j)
        
    path = find_path(maze, start)
    print("path: ", path)

    path += '\n'

    s.send(path.encode())
    tmp = s.recv(1024)    
    flag = s.recv(1024).decode()[1:]

    print('flag:\n' + flag)
    s.close()
    break