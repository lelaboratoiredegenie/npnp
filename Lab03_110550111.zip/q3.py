from pwn import *

r = remote("inp.zoolab.org", 10303)

maze = [['n' for _ in range(250)] for _ in range(250)]

def find_path(start):
    stack = []
    stack.append((start, ""))
    visited = []
    visited.append(start)
    path = ''
    while stack:
        cur, cur_path = stack.pop(-1)
        y = cur[0]
        x = cur[1]
        if maze[y][x] == 'E':
            path = cur_path
            break

        if maze[y-1][x] == 'n' or maze[y+1][x] == 'n' or maze[y][x+1] == 'n' or maze[y][x-1] == 'n':
            path = cur_path
            break

        if maze[y-1][x] in ['.', 'E', '*'] and (y-1, x) not in visited:
            stack.append(((y-1, x), cur_path+'W'))
            visited.append((y-1, x))
        if maze[y+1][x] in ['.', 'E', '*'] and (y+1, x) not in visited:
            stack.append(((y+1, x), cur_path+'S'))
            visited.append((y+1, x))
        if maze[y][x-1] in ['.', 'E', '*'] and (y, x-1) not in visited:
            stack.append(((y, x-1) , cur_path+'A'))
            visited.append((y, x-1))
        if maze[y][x+1] in ['.', 'E', '*'] and (y, x+1) not in visited:
            stack.append(((y, x+1), cur_path+'D'))
            visited.append((y, x+1))

    return path, (y,x)

for i in range(11):
    response = r.recvline() #ini

for i in range(7):
    response = r.recvline().decode()  #first maze
    for j in range(0, 10):
        maze[int(response[2:5])][105 + j] = response[7 + j]
        if response[7 + j] == '*':
            start = (int(response[2:5]), 105 + j)

while 'BINGO!' not in response:
# for _ in range(5):

    p, (y,x) = find_path(start)

    start = (y,x)

    if p == "":
        break

    print(p+' '+str(x)+','+str(y))

    r.sendline(p.encode())

    resp = r.recvline().decode()
    print(resp)
    if 'BINGO!' in resp:
        break

    resp = r.recvline().decode()
    print(resp)
    if 'BINGO!' in resp:
        break

    resp = r.recvline().decode()
    print(resp)
    if 'BINGO!' in resp:
        break


    for i in range(7):
        response = r.recvline().decode()
        for j in range(0,10):
            maze[int(response[2:5])][x - 5 + j] = response[7 + j]

r.close()